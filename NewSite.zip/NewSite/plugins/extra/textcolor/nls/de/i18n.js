define({
	"button.textcolor.tooltip": "Textfarbe ändern"
});
