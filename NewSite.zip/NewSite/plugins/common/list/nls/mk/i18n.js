define({
	"button.createulist.tooltip": "Внеси неподредена листа",
	"button.createolist.tooltip": "Внеси подредена листа",
	"button.indentlist.tooltip": "Зголеми растојание на листа од внатре",
	"button.outdentlist.tooltip": "Зголеми растојание на листа од надвор",
	"floatingmenu.tab.list": "Листи"
});
