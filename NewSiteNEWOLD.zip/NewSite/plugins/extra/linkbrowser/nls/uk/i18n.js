define({
	"button.addlink.tooltip": "Вставити посилання",
	"button.removelink.tooltip": "Видалити посилання",
	"newlink.defaulttext": "Нове посилання",
	"floatingmenu.tab.link": "Посилання"
});
