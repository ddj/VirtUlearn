define({
	"button.addlink.tooltip": "Внеси линк",
	"button.removelink.tooltip": "Одстрани линк",
	"newlink.defaulttext": "Нов линк",
	"floatingmenu.tab.link": "Линк",
	"link.target.self": "Себеси",
	"link.target.blank": "Празно",
	"link.target.parent": "Родител",
	"link.target.top": "Најгоре",
	"link.target.framename": "Име на рамката",
	"link.target.legend": "Мета",
	"link.title.legend": "Наслов",
	"insertLink": "ctrl+k"
});
