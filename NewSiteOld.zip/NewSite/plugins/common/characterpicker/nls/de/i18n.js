define({
	"button.addcharacter.tooltip": "Sonderzeichen wählen"
});
