define({
	"button.createulist.tooltip": "Вставити невідсортований список",
	"button.createolist.tooltip": "Вставити відсортований список",
	"button.indentlist.tooltip": "Список з відступом",
	"button.outdentlist.tooltip": "Список з виступом",
	"floatingmenu.tab.list": "Списки"
});
