define({
	"button.addlink.tooltip": "Verweis einfügen",
	"button.removelink.tooltip": "Verweis entfernen",
	"newlink.defaulttext": "Neuer Verweis",
	"floatingmenu.tab.link": "Verweis",
	"link.target.self": "Gleiches Fenster",
	"link.target.blank": "Neues Fenster",
	"link.target.parent": "Elternfenster",
	"link.target.top": "Hauptfenster",
	"link.target.framename": "Framename",
	"link.target.legend": "Ziel",
	"link.title.legend": "Titel",
	"insertLink": "Ctrl+k"
});
